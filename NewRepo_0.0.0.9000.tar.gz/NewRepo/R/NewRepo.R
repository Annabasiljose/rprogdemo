#' NewRepo: A package for calculating the sum
#'
#' The NewRepo package provides 2 inputs
#' a and b
#'
#' @section NewRepo functions:
#' add_two_numbers
#'
#' @docType package
#' @name NewRepo
#'
NULL
