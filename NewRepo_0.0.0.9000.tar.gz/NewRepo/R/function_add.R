#' Calculate the sum from 2 numbers given
#' @param a First integer
#' @param b Second param
#' @export

add_two_numbers <- function(a, b){
  sum_of_numbers <- a + b
  return(sum_of_numbers)
}
